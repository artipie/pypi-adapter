# Example Package
for integration test of Artipie project